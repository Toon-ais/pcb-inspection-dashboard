import React, { useState, useMemo } from 'react';

// ----------------------------------------------------------------
// VERIFIED DATA – extracted from "Calculation Page Verified.xlsx"
// ----------------------------------------------------------------
const ALL_DATA: Record<string, Record<string, { dX: number; cX: number; dY: number; cY: number; ccdX: number; ccdY: number }>> = {
  "L1": {
    "POW_1.1":  { dX:24.9, cX:0.06278320000000193, dY:37.35, cY:0.29084870000000507, ccdX:24.86, ccdY:37.077 },
    "POW_1.2":  { dX:24.9, cX:0.05209700000000339, dY:32.35, cY:0.2602266999999969, ccdX:24.83, ccdY:32.121 },
    "PIN_2":    { dX:23.3, cX:0.065469199999999, dY:26.95, cY:0.199691099999999, ccdX:23.27, ccdY:26.739 },
    "PIN_3":    { dX:23.3, cX:0.056016700000000696, dY:22.95, cY:0.18983360000000005, ccdX:23.236, ccdY:22.732 },
    "PIN_4":    { dX:23.3, cX:0.0501749000000018, dY:18.95, cY:0.22212120000000013, ccdX:23.229, ccdY:18.716 },
    "PIN_5":    { dX:23.3, cX:0.05274689999999893, dY:14.95, cY:0.2646189999999997, ccdX:23.203, ccdY:14.651 },
    "PIN_6":    { dX:23.3, cX:0.027013600000000082, dY:10.95, cY:0.2289469000000004, ccdX:23.245, ccdY:10.682 },
    "PIN_7":    { dX:23.3, cX:0.005876600000000565, dY:6.95, cY:0.2506396999999998, ccdX:23.272, ccdY:6.654 },
    "PIN_8":    { dX:23.3, cX:-0.0007598999999984812, dY:2.95, cY:0.2446195000000002, ccdX:23.302, ccdY:2.654 },
    "PIN_9":    { dX:23.3, cX:0.019280200000000747, dY:-1.05, cY:0.22433670000000006, ccdX:23.268, ccdY:-1.324 },
    "PIN_10":   { dX:23.3, cX:0.00802060000000182, dY:-5.05, cY:0.21487709999999982, ccdX:23.307, ccdY:-5.311 },
    "PIN_11":   { dX:23.3, cX:-0.007522699999999105, dY:-9.05, cY:0.21849510000000016, ccdX:23.311, ccdY:-9.303 },
    "PIN_12":   { dX:23.3, cX:-0.050242399999998355, dY:-13.05, cY:0.24121320000000068, ccdX:23.345, ccdY:-13.348 },
    "POW_13.1": { dX:24.9, cX:-0.09501029999999844, dY:-18.45, cY:0.42392889999999994, ccdX:25.026, ccdY:-18.903 },
    "POW_13.2": { dX:24.9, cX:-0.10065849999999799, dY:-23.45, cY:0.3982367999999994, ccdX:24.976, ccdY:-23.868 },
    "PIN_14":   { dX:27.3, cX:0.07403150000000025, dY:26.95, cY:0.1788070000000026, ccdX:27.316, ccdY:26.755 },
    "PIN_15":   { dX:27.3, cX:0.05882569999999987, dY:22.95, cY:0.1823756000000003, ccdX:27.311, ccdY:22.761 },
    "PIN_16":   { dX:27.3, cX:0.04809889999999939, dY:18.95, cY:0.19812470000000104, ccdX:27.353, ccdY:18.72 },
    "PIN_17":   { dX:27.3, cX:0.07279169999999979, dY:14.95, cY:0.19262010000000096, ccdX:27.283, ccdY:14.757 },
    "PIN_18":   { dX:27.3, cX:-0.038411799999998664, dY:10.95, cY:0.1683570000000003, ccdX:27.392, ccdY:10.795 },
    "PIN_19":   { dX:27.3, cX:0.020043599999997497, dY:6.95, cY:0.19590330000000034, ccdX:27.364, ccdY:6.701 },
    "PIN_20":   { dX:27.3, cX:-0.002134900000001494, dY:2.95, cY:0.22383750000000013, ccdX:27.376, ccdY:2.662 },
    "PIN_21":   { dX:27.3, cX:-0.013417699999997978, dY:-1.05, cY:0.21884740000000003, ccdX:27.395, ccdY:-1.326 },
    "PIN_22":   { dX:27.3, cX:-0.026952599999997773, dY:-5.05, cY:0.23074569999999994, ccdX:27.438, ccdY:-5.34 },
    "PIN_23":   { dX:27.3, cX:-0.04154020000000003, dY:-9.05, cY:0.2097073999999992, ccdX:27.422, ccdY:-9.302 },
    "PIN_24":   { dX:27.3, cX:-0.05656809999999979, dY:-13.05, cY:0.22348129999999955, ccdX:27.457, ccdY:-13.327 },
    "PIN_25":   { dX:32.7, cX:0.10397849999999664, dY:35.75, cY:0.3609390000000019, ccdX:32.497, ccdY:35.369 },
    "PIN_26":   { dX:33.05, cX:0.10570770000000351, dY:28.95, cY:0.20931320000000042, ccdX:33.047, ccdY:28.746 },
    "PIN_27":   { dX:33.05, cX:0.09473229999999688, dY:24.95, cY:0.17281879999999816, ccdX:33.051, ccdY:24.809 },
    "PIN_28":   { dX:33.05, cX:0.0849441000000013, dY:20.95, cY:0.1600873000000007, ccdX:33.119, ccdY:20.801 },
    "PIN_29":   { dX:33.05, cX:0.07701349999999962, dY:16.95, cY:0.20396279999999933, ccdX:33.17, ccdY:16.735 },
    "PIN_30":   { dX:33.05, cX:0.14505969999999735, dY:12.95, cY:0.14504420000000096, ccdX:33.036, ccdY:12.815 },
    "PIN_31":   { dX:33.05, cX:0.08753490000000141, dY:8.95, cY:0.18844569999999905, ccdX:33.088, ccdY:8.768 },
    "PIN_32":   { dX:33.05, cX:0.03391940000000204, dY:4.95, cY:0.20965729999999994, ccdX:33.159, ccdY:4.713 },
    "PIN_33":   { dX:33.05, cX:0.02134560000000363, dY:0.95, cY:0.2218682999999999, ccdX:33.108, ccdY:0.681 },
    "PIN_34":   { dX:33.05, cX:0.008368199999999604, dY:-3.05, cY:0.21779060000000028, ccdX:33.118, ccdY:-3.297 },
    "PIN_35":   { dX:33.05, cX:-0.006077999999995143, dY:-7.05, cY:0.20454759999999972, ccdX:33.178, ccdY:-7.306 },
    "PIN_36":   { dX:33.05, cX:-0.027042100000002733, dY:-11.05, cY:0.19945109999999922, ccdX:33.109, ccdY:-11.318 },
    "PIN_37":   { dX:33.05, cX:-0.03636889999999937, dY:-15.05, cY:0.20796379999999992, ccdX:33.165, ccdY:-15.315 },
    "PIN_38":   { dX:32.7, cX:-0.09300149999999974, dY:-21.85, cY:0.42026839999999765, ccdX:32.687, ccdY:-22.336 },
    "E_1":      { dX:-36, cX:0.01057209999999742, dY:-7.35, cY:0.33246209999999987, ccdX:-36.032, ccdY:-7.779 },
    "E_2":      { dX:-36, cX:-0.029481699999998057, dY:-32.35, cY:0.2948176000000018, ccdX:-35.99, ccdY:-32.774 },
    "E_4":      { dX:-63.6, cX:0.047154999999996505, dY:-29, cY:0.28965690000000066, ccdX:-63.653, ccdY:-29.303 },
    "E_5":      { dX:-33.5, cX:0.10682839999999771, dY:28.15, cY:0.3758450999999994, ccdX:-33.619, ccdY:27.846 },
    "E_6":      { dX:-33.5, cX:0.09200670000000599, dY:23.15, cY:0.35793819999999954, ccdX:-33.639, ccdY:22.854 },
    "E_7":      { dX:-38.5, cX:0.05664469999999966, dY:23.15, cY:0.22430849999999936, ccdX:-38.491, ccdY:23.001 },
    "E_8":      { dX:-38.5, cX:0.1114820000000023, dY:28.15, cY:0.32392660000000006, ccdX:-38.514, ccdY:27.908 }
  },
  "L2": {
    "POW_1.1":  { dX:24.9, cX:0.02224350000000186, dY:37.35, cY:0.2866469000000009, ccdX:24.9, ccdY:37.088 },
    "POW_1.2":  { dX:24.9, cX:0.010252099999998876, dY:32.35, cY:0.2495349999999945, ccdX:24.841, ccdY:32.139 },
    "PIN_2":    { dX:23.3, cX:0.021295099999999678, dY:26.95, cY:0.20476599999999934, ccdX:23.273, ccdY:26.725 },
    "PIN_3":    { dX:23.3, cX:0.01725070000000173, dY:22.95, cY:0.231869200000002, ccdX:23.27, ccdY:22.673 },
    "PIN_4":    { dX:23.3, cX:0.01103599999999716, dY:18.95, cY:0.2523793999999988, ccdX:23.26, ccdY:18.666 },
    "PIN_5":    { dX:23.3, cX:0.02077109999999749, dY:14.95, cY:0.2922861999999995, ccdX:23.225, ccdY:14.587 },
    "PIN_6":    { dX:23.3, cX:-0.0066785999999972034, dY:10.95, cY:0.2554300000000005, ccdX:23.281, ccdY:10.613 },
    "PIN_7":    { dX:23.3, cX:-0.017817999999998335, dY:6.95, cY:0.26718699999999984, ccdX:23.279, ccdY:6.599 },
    "PIN_8":    { dX:23.3, cX:-0.032059300000000235, dY:2.95, cY:0.27805729999999995, ccdX:23.289, ccdY:2.576 },
    "PIN_9":    { dX:23.3, cX:-0.012434000000002499, dY:-1.05, cY:0.26622409999999985, ccdX:23.289, ccdY:-1.396 },
    "PIN_10":   { dX:23.3, cX:-0.023610699999998985, dY:-5.05, cY:0.24360180000000042, ccdX:23.293, ccdY:-5.371 },
    "PIN_11":   { dX:23.3, cX:-0.029563700000000637, dY:-9.05, cY:0.22319850000000052, ccdX:23.324, ccdY:-9.349 },
    "PIN_12":   { dX:23.3, cX:-0.07312879999999922, dY:-13.05, cY:0.27474360000000075, ccdX:23.358, ccdY:-13.416 },
    "POW_13.1": { dX:24.9, cX:-0.11628389999999911, dY:-18.45, cY:0.3962363999999994, ccdX:25.038, ccdY:-18.891 },
    "POW_13.2": { dX:24.9, cX:-0.1232465999999981, dY:-23.45, cY:0.38283059999999836, ccdX:24.988, ccdY:-23.868 },
    "PIN_14":   { dX:27.3, cX:0.03499559999999846, dY:26.95, cY:0.22235410000000044, ccdX:27.277, ccdY:26.681 },
    "PIN_15":   { dX:27.3, cX:0.0204974, dY:22.95, cY:0.21464750000000166, ccdX:27.266, ccdY:22.708 },
    "PIN_16":   { dX:27.3, cX:0.01282730000000143, dY:18.95, cY:0.23241769999999917, ccdX:27.288, ccdY:18.68 },
    "PIN_17":   { dX:27.3, cX:0.0385548, dY:14.95, cY:0.1866532000000003, ccdX:27.225, ccdY:14.737 },
    "PIN_18":   { dX:27.3, cX:-0.06450010000000006, dY:10.95, cY:0.1778051000000005, ccdX:27.338, ccdY:10.754 },
    "PIN_19":   { dX:27.3, cX:-0.014705600000002761, dY:6.95, cY:0.2215745, ccdX:27.292, ccdY:6.647 },
    "PIN_20":   { dX:27.3, cX:-0.028866500000003015, dY:2.95, cY:0.22165420000000013, ccdX:27.318, ccdY:2.645 },
    "PIN_21":   { dX:27.3, cX:-0.03961740000000091, dY:-1.05, cY:0.22315780000000007, ccdX:27.324, ccdY:-1.354 },
    "PIN_22":   { dX:27.3, cX:-0.05450739999999854, dY:-5.05, cY:0.20399220000000007, ccdX:27.397, ccdY:-5.35 },
    "PIN_23":   { dX:27.3, cX:-0.06412849999999892, dY:-9.05, cY:0.19640389999999996, ccdX:27.378, ccdY:-9.332 },
    "PIN_24":   { dX:27.3, cX:-0.07880980000000193, dY:-13.05, cY:0.2634841000000012, ccdX:27.42, ccdY:-13.409 },
    "PIN_25":   { dX:32.7, cX:0.06219779999999986, dY:35.75, cY:0.3168542999999957, ccdX:32.511, ccdY:35.45 },
    "PIN_26":   { dX:33.05, cX:0.06622869999999637, dY:28.95, cY:0.19015740000000037, ccdX:33.015, ccdY:28.733 },
    "PIN_27":   { dX:33.05, cX:0.056198300000005474, dY:24.95, cY:0.18479119999999938, ccdX:33.01, ccdY:24.747 },
    "PIN_28":   { dX:33.05, cX:0.04721550000000008, dY:20.95, cY:0.18453269999999833, ccdX:33.074, ccdY:20.736 },
    "PIN_29":   { dX:33.05, cX:0.034737399999997365, dY:16.95, cY:0.2281205999999969, ccdX:33.091, ccdY:16.67 },
    "PIN_30":   { dX:33.05, cX:0.09887179999999773, dY:12.95, cY:0.17744560000000043, ccdX:32.969, ccdY:12.743 },
    "PIN_31":   { dX:33.05, cX:0.043234200000000556, dY:8.95, cY:0.20594430000000052, ccdX:32.979, ccdY:8.721 },
    "PIN_32":   { dX:33.05, cX:-0.000801199999997948, dY:4.95, cY:0.2513860999999995, ccdX:33.091, ccdY:4.634 },
    "PIN_33":   { dX:33.05, cX:-0.012875200000003417, dY:0.95, cY:0.22702579999999994, ccdX:33.078, ccdY:0.652 },
    "PIN_34":   { dX:33.05, cX:-0.027134600000003672, dY:-3.05, cY:0.2382428000000001, ccdX:33.07, ccdY:-3.355 },
    "PIN_35":   { dX:33.05, cX:-0.037018000000003326, dY:-7.05, cY:0.1874336000000003, ccdX:33.09, ccdY:-7.333 },
    "PIN_36":   { dX:33.05, cX:-0.055254499999996654, dY:-11.05, cY:0.1931396000000003, ccdX:33.062, ccdY:-11.344 },
    "PIN_37":   { dX:33.05, cX:-0.06795559999999767, dY:-15.05, cY:0.19926519999999925, ccdX:33.104, ccdY:-15.338 },
    "PIN_38":   { dX:32.7, cX:-0.1152546000000001, dY:-21.85, cY:0.4353283999999995, ccdX:32.703, ccdY:-22.39 },
    "E_1":      { dX:-36, cX:-0.024503799999997966, dY:-7.35, cY:0.24583530000000042, ccdX:-36, ccdY:-7.657 },
    "E_2":      { dX:-36, cX:-0.04782390000000447, dY:-32.35, cY:0.29150169999999775, ccdX:-35.916, ccdY:-32.788 },
    "E_4":      { dX:-63.6, cX:0.008575499999999181, dY:-29, cY:0.2696418999999999, ccdX:-63.668, ccdY:-29.303 },
    "E_5":      { dX:-33.5, cX:0.04365479999999877, dY:28.15, cY:0.354307900000002, ccdX:-33.551, ccdY:27.918 },
    "E_6":      { dX:-33.5, cX:0.03497989999999618, dY:23.15, cY:0.3705715999999981, ccdX:-33.577, ccdY:22.893 },
    "E_7":      { dX:-38.5, cX:0.08539069999999782, dY:23.15, cY:0.26282420000000073, ccdX:-38.469, ccdY:23.023 },
    "E_8":      { dX:-38.5, cX:0.05436180000000235, dY:28.15, cY:0.3163890000000009, ccdX:-38.418, ccdY:27.976 }
  },
  "X1": {
    "POW_1.1":  { dX:24.9, cX:0.08040460000000138, dY:37.35, cY:0.3020235999999983, ccdX:24.804, ccdY:37.124 },
    "POW_1.2":  { dX:24.9, cX:0.05556130000000081, dY:32.35, cY:0.2511247999999995, ccdX:24.784, ccdY:32.186 },
    "PIN_2":    { dX:23.3, cX:0.05943120000000235, dY:26.95, cY:0.19941490000000073, ccdX:23.223, ccdY:26.778 },
    "PIN_3":    { dX:23.3, cX:0.05130180000000095, dY:22.95, cY:0.20590569999999886, ccdX:23.207, ccdY:22.751 },
    "PIN_4":    { dX:23.3, cX:0.043422499999998365, dY:18.95, cY:0.22756309999999758, ccdX:23.204, ccdY:18.754 },
    "PIN_5":    { dX:23.3, cX:0.05067100000000124, dY:14.95, cY:0.2843872000000012, ccdX:23.185, ccdY:14.684 },
    "PIN_6":    { dX:23.3, cX:0.020338100000000026, dY:10.95, cY:0.25166549999999965, ccdX:23.27, ccdY:10.69 },
    "PIN_7":    { dX:23.3, cX:0.004700899999999564, dY:6.95, cY:0.25207020000000036, ccdX:23.268, ccdY:6.697 },
    "PIN_8":    { dX:23.3, cX:-0.008604400000002954, dY:2.95, cY:0.25487860000000007, ccdX:23.295, ccdY:2.695 },
    "PIN_9":    { dX:23.3, cX:0.011544399999998234, dY:-1.05, cY:0.2417480999999999, ccdX:23.25, ccdY:-1.305 },
    "PIN_10":   { dX:23.3, cX:-0.004021200000000391, dY:-5.05, cY:0.22964889999999993, ccdX:23.306, ccdY:-5.276 },
    "PIN_11":   { dX:23.3, cX:-0.013411699999998916, dY:-9.05, cY:0.21909249999999858, ccdX:23.297, ccdY:-9.264 },
    "PIN_12":   { dX:23.3, cX:-0.06366470000000035, dY:-13.05, cY:0.2607638999999988, ccdX:23.344, ccdY:-13.325 },
    "POW_13.1": { dX:24.9, cX:-0.10517189999999843, dY:-18.45, cY:0.39980059999999895, ccdX:25.061, ccdY:-18.822 },
    "POW_13.2": { dX:24.9, cX:-0.12373679999999965, dY:-23.45, cY:0.3734648999999983, ccdX:24.991, ccdY:-23.787 },
    "PIN_14":   { dX:27.3, cX:0.07054640000000134, dY:26.95, cY:0.22213879999999975, ccdX:27.281, ccdY:26.756 },
    "PIN_15":   { dX:27.3, cX:0.06270590000000098, dY:22.95, cY:0.21295780000000164, ccdX:27.235, ccdY:22.752 },
    "PIN_16":   { dX:27.3, cX:0.04200529999999958, dY:18.95, cY:0.20950819999999837, ccdX:27.299, ccdY:18.742 },
    "PIN_17":   { dX:27.3, cX:0.066401299999999, dY:14.95, cY:0.21054900000000032, ccdX:27.224, ccdY:14.759 },
    "PIN_18":   { dX:27.3, cX:-0.04267109999999974, dY:10.95, cY:0.19759729999999998, ccdX:27.343, ccdY:10.797 },
    "PIN_19":   { dX:27.3, cX:0.006247799999997028, dY:6.95, cY:0.23898679999999928, ccdX:27.321, ccdY:6.682 },
    "PIN_20":   { dX:27.3, cX:-0.008472900000001005, dY:2.95, cY:0.2440237999999999, ccdX:27.326, ccdY:2.689 },
    "PIN_21":   { dX:27.3, cX:-0.02582519999999988, dY:-1.05, cY:0.22943579999999986, ccdX:27.349, ccdY:-1.313 },
    "PIN_22":   { dX:27.3, cX:-0.03168850000000134, dY:-5.05, cY:0.20789650000000037, ccdX:27.401, ccdY:-5.266 },
    "PIN_23":   { dX:27.3, cX:-0.052262699999999995, dY:-9.05, cY:0.19289989999999868, ccdX:27.386, ccdY:-9.235 },
    "PIN_24":   { dX:27.3, cX:-0.06882650000000012, dY:-13.05, cY:0.22555180000000163, ccdX:27.454, ccdY:-13.287 },
    "PIN_25":   { dX:32.7, cX:0.10653020000000168, dY:35.75, cY:0.3595423000000011, ccdX:32.405, ccdY:35.437 },
    "PIN_26":   { dX:33.05, cX:0.10008189999999928, dY:28.95, cY:0.22144220000000203, ccdX:32.991, ccdY:28.711 },
    "PIN_27":   { dX:33.05, cX:0.09216490000000022, dY:24.95, cY:0.1885741000000003, ccdX:32.93, ccdY:24.756 },
    "PIN_28":   { dX:33.05, cX:0.08379029999999688, dY:20.95, cY:0.20182909999999765, ccdX:32.856, ccdY:20.731 },
    "PIN_29":   { dX:33.05, cX:0.0618150999999969, dY:16.95, cY:0.2176587000000012, ccdX:32.96, ccdY:16.694 },
    "PIN_30":   { dX:33.05, cX:0.12739340000000254, dY:12.95, cY:0.1663963000000006, ccdX:32.891, ccdY:12.763 },
    "PIN_31":   { dX:33.05, cX:0.06278180000000333, dY:8.95, cY:0.22495390000000093, ccdX:33.034, ccdY:8.693 },
    "PIN_32":   { dX:33.05, cX:0.025495099999993442, dY:4.95, cY:0.2240599000000003, ccdX:33.023, ccdY:4.667 },
    "PIN_33":   { dX:33.05, cX:0.010656799999999578, dY:0.95, cY:0.22411789999999998, ccdX:33.095, ccdY:0.751 },
    "PIN_34":   { dX:33.05, cX:-0.010338799999999537, dY:-3.05, cY:0.21983059999999988, ccdX:33.116, ccdY:-3.326 },
    "PIN_35":   { dX:33.05, cX:-0.021699600000005148, dY:-7.05, cY:0.20971019999999996, ccdX:33.142, ccdY:-7.28 },
    "PIN_36":   { dX:33.05, cX:-0.0370632999999998, dY:-11.05, cY:0.1925737999999999, ccdX:33.15, ccdY:-11.272 },
    "PIN_37":   { dX:33.05, cX:-0.05073539999999355, dY:-15.05, cY:0.21871980000000057, ccdX:33.169, ccdY:-15.289 },
    "PIN_38":   { dX:32.7, cX:-0.11757149999999683, dY:-21.85, cY:0.41168869999999913, ccdX:32.662, ccdY:-22.227 },
    "E_1":      { dX:-36, cX:-0.007068400000001418, dY:-7.35, cY:0.2598769000000001, ccdX:-36.049, ccdY:-7.648 },
    "E_2":      { dX:-36, cX:-0.039257700000000284, dY:-32.35, cY:0.24508459999999843, ccdX:-35.98, ccdY:-32.727 },
    "E_4":      { dX:-63.6, cX:0.021094300000001454, dY:-29, cY:0.22143900000000016, ccdX:-63.738, ccdY:-29.182 },
    "E_5":      { dX:-33.5, cX:0.09501730000000208, dY:28.15, cY:0.35133710000000207, ccdX:-33.621, ccdY:27.883 },
    "E_6":      { dX:-33.5, cX:0.07775000000000176, dY:23.15, cY:0.36679050000000046, ccdX:-33.64, ccdY:22.86 },
    "E_7":      { dX:-38.5, cX:0.05025579999999508, dY:23.15, cY:0.22815539999999856, ccdX:-38.65, ccdY:23.023 },
    "E_8":      { dX:-38.5, cX:0.09598330000000033, dY:28.15, cY:0.3156725999999992, ccdX:-38.674, ccdY:27.944 }
  },
  "X2": {
    "POW_1.1":  { dX:24.9, cX:0.041221000000000174, dY:37.35, cY:0.28754849999999976, ccdX:24.834, ccdY:37.113 },
    "POW_1.2":  { dX:24.9, cX:0.03689470000000128, dY:32.35, cY:0.24890770000000373, ccdX:24.781, ccdY:32.165 },
    "PIN_2":    { dX:23.3, cX:0.041684899999999914, dY:26.95, cY:0.20152870000000078, ccdX:23.248, ccdY:26.733 },
    "PIN_3":    { dX:23.3, cX:0.036387999999998755, dY:22.95, cY:0.21643549999999934, ccdX:23.257, ccdY:22.734 },
    "PIN_4":    { dX:23.3, cX:0.03066570000000013, dY:18.95, cY:0.2456657, ccdX:23.228, ccdY:18.708 },
    "PIN_5":    { dX:23.3, cX:0.035697599999998886, dY:14.95, cY:0.29000249999999994, ccdX:23.192, ccdY:14.63 },
    "PIN_6":    { dX:23.3, cX:0.0031679000000011115, dY:10.95, cY:0.25150320000000015, ccdX:23.273, ccdY:10.665 },
    "PIN_7":    { dX:23.3, cX:-0.008299300000000898, dY:6.95, cY:0.26882370000000044, ccdX:23.292, ccdY:6.653 },
    "PIN_8":    { dX:23.3, cX:-0.02376989999999779, dY:2.95, cY:0.2539482000000004, ccdX:23.298, ccdY:2.659 },
    "PIN_9":    { dX:23.3, cX:-0.0000630000000008124, dY:-1.05, cY:0.24137209999999998, ccdX:23.25, ccdY:-1.327 },
    "PIN_10":   { dX:23.3, cX:-0.022958600000002605, dY:-5.05, cY:0.22313340000000004, ccdX:23.295, ccdY:-5.303 },
    "PIN_11":   { dX:23.3, cX:-0.031486300000000966, dY:-9.05, cY:0.2286753000000008, ccdX:23.279, ccdY:-9.319 },
    "PIN_12":   { dX:23.3, cX:-0.07540339999999901, dY:-13.05, cY:0.26000140000000016, ccdX:23.38, ccdY:-13.345 },
    "POW_13.1": { dX:24.9, cX:-0.1238942999999999, dY:-18.45, cY:0.3975393000000018, ccdX:25.04, ccdY:-18.861 },
    "POW_13.2": { dX:24.9, cX:-0.1299599000000029, dY:-23.45, cY:0.3830279999999995, ccdX:24.978, ccdY:-23.84 },
    "PIN_14":   { dX:27.3, cX:0.052087199999999, dY:26.95, cY:0.21484490000000278, ccdX:27.311, ccdY:26.708 },
    "PIN_15":   { dX:27.3, cX:0.043864399999996806, dY:22.95, cY:0.20717939999999757, ccdX:27.26, ccdY:22.736 },
    "PIN_16":   { dX:27.3, cX:0.030201500000000436, dY:18.95, cY:0.2387087000000001, ccdX:27.287, ccdY:18.693 },
    "PIN_17":   { dX:27.3, cX:0.04902359999999817, dY:14.95, cY:0.20278030000000058, ccdX:27.234, ccdY:14.747 },
    "PIN_18":   { dX:27.3, cX:-0.0531624000000015, dY:10.95, cY:0.19951000000000008, ccdX:27.346, ccdY:10.769 },
    "PIN_19":   { dX:27.3, cX:-0.0036678000000023303, dY:6.95, cY:0.23362699999999936, ccdX:27.335, ccdY:6.666 },
    "PIN_20":   { dX:27.3, cX:-0.02402980000000099, dY:2.95, cY:0.23837870000000017, ccdX:27.327, ccdY:2.667 },
    "PIN_21":   { dX:27.3, cX:-0.0407396999999996, dY:-1.05, cY:0.23087880000000016, ccdX:27.37, ccdY:-1.324 },
    "PIN_22":   { dX:27.3, cX:-0.051708200000000204, dY:-5.05, cY:0.22278429999999982, ccdX:27.381, ccdY:-5.318 },
    "PIN_23":   { dX:27.3, cX:-0.06410629999999884, dY:-9.05, cY:0.19959859999999985, ccdX:27.38, ccdY:-9.284 },
    "PIN_24":   { dX:27.3, cX:-0.07857600000000176, dY:-13.05, cY:0.20188199999999945, ccdX:27.388, ccdY:-13.29 },
    "PIN_25":   { dX:32.7, cX:0.0904275000000041, dY:35.75, cY:0.3266619999999989, ccdX:32.416, ccdY:35.451 },
    "PIN_26":   { dX:33.05, cX:0.0857055000000031, dY:28.95, cY:0.23305440000000033, ccdX:33.001, ccdY:28.657 },
    "PIN_27":   { dX:33.05, cX:0.07590140000000645, dY:24.95, cY:0.19619810000000015, ccdX:32.974, ccdY:24.703 },
    "PIN_28":   { dX:33.05, cX:0.06417989999999918, dY:20.95, cY:0.2098875999999983, ccdX:32.879, ccdY:20.701 },
    "PIN_29":   { dX:33.05, cX:0.0499723000000003, dY:16.95, cY:0.20982330000000005, ccdX:33.034, ccdY:16.688 },
    "PIN_30":   { dX:33.05, cX:0.11371830000000216, dY:12.95, cY:0.20631859999999946, ccdX:32.925, ccdY:12.676 },
    "PIN_31":   { dX:33.05, cX:0.05524989999999974, dY:8.95, cY:0.2280042999999985, ccdX:33.053, ccdY:8.675 },
    "PIN_32":   { dX:33.05, cX:0.007852700000000823, dY:4.95, cY:0.22699300000000022, ccdX:33.06, ccdY:4.668 },
    "PIN_33":   { dX:33.05, cX:-0.005297800000001018, dY:0.95, cY:0.2301318, ccdX:33.087, ccdY:0.718 },
    "PIN_34":   { dX:33.05, cX:-0.016175500000002785, dY:-3.05, cY:0.23448560000000018, ccdX:33.124, ccdY:-3.363 },
    "PIN_35":   { dX:33.05, cX:-0.02813199999999938, dY:-7.05, cY:0.21642389999999967, ccdX:33.127, ccdY:-7.343 },
    "PIN_36":   { dX:33.05, cX:-0.04419469999999848, dY:-11.05, cY:0.2160373, ccdX:33.14, ccdY:-11.347 },
    "PIN_37":   { dX:33.05, cX:-0.059788300000001016, dY:-15.05, cY:0.22467719999999858, ccdX:33.155, ccdY:-15.338 },
    "PIN_38":   { dX:32.7, cX:-0.11968980000000329, dY:-21.85, cY:0.40594580000000136, ccdX:32.643, ccdY:-22.251 },
    "E_1":      { dX:-36, cX:-0.015315600000000984, dY:-7.35, cY:0.2603909, ccdX:-36.106, ccdY:-7.656 },
    "E_2":      { dX:-36, cX:-0.047368299999995145, dY:-32.35, cY:0.2508082000000016, ccdX:-36.081, ccdY:-32.71 },
    "E_4":      { dX:-63.6, cX:0.009277099999998484, dY:-29, cY:0.20200519999999855, ccdX:-63.733, ccdY:-29.173 },
    "E_5":      { dX:-33.5, cX:0.08650779999999969, dY:28.15, cY:0.36288860000000156, ccdX:-33.566, ccdY:27.851 },
    "E_6":      { dX:-33.5, cX:0.054321200000003955, dY:23.15, cY:0.35296590000000094, ccdX:-33.579, ccdY:22.854 },
    "E_7":      { dX:-38.5, cX:0.02818480000000534, dY:23.15, cY:0.22849640000000093, ccdX:-38.566, ccdY:23.016 },
    "E_8":      { dX:-38.5, cX:0.08530939999999987, dY:28.15, cY:0.33334040000000087, ccdX:-38.6, ccdY:27.918 }
  }
};

const CAVITIES = ['L1', 'L2', 'X1', 'X2'] as const;
type Cavity = typeof CAVITIES[number];
const PIN_NAMES = Object.keys(ALL_DATA.L1);

interface PinReading {
  ccdX: number;
  ccdY: number;
  tempX: number;
  tempY: number;
}

interface ComputedResult {
  xOff: number;
  yOff: number;
  length: number;
}

function computeOffsets(
  pin: string,
  ccdX: number,
  ccdY: number,
  tempX: number,
  tempY: number,
  cavity: Cavity
): ComputedResult | null {
  const info = ALL_DATA[cavity]?.[pin];
  if (!info) return null;
  const xOff = ccdX + info.cX + tempX - info.dX;
  const yOff = ccdY + info.cY + tempY - info.dY;
  const length = 2 * Math.sqrt(xOff * xOff + yOff * yOff);
  return { xOff, yOff, length };
}

function computeRequiredTemp(
  pin: string,
  ccdX: number,
  ccdY: number,
  targetLength: number,
  cavity: Cavity
) {
  const info = ALL_DATA[cavity]?.[pin];
  if (!info) return null;
  const baseX = ccdX + info.cX - info.dX;
  const baseY = ccdY + info.cY - info.dY;
  const currentLen = 2 * Math.sqrt(baseX * baseX + baseY * baseY);
  if (currentLen <= targetLength) {
    return { tempX: 0, tempY: 0, achievedLen: currentLen };
  }
  const scale = targetLength / currentLen;
  const newX = baseX * scale;
  const newY = baseY * scale;
  const reqX = newX - baseX;
  const reqY = newY - baseY;
  const achievedLen = 2 * Math.sqrt(newX * newX + newY * newY);
  return { tempX: reqX, tempY: reqY, achievedLen };
}

function createInitialReadings(): Record<string, PinReading> {
  const readings: Record<string, PinReading> = {};
  for (const cavity of CAVITIES) {
    for (const pin of PIN_NAMES) {
      const key = `${cavity}|${pin}`;
      const info = ALL_DATA[cavity][pin];
      readings[key] = { ccdX: info.ccdX, ccdY: info.ccdY, tempX: 0, tempY: 0 };
    }
  }
  return readings;
}

function useRecentChanges(values: Record<string, number>, duration = 20000) {
  const previous = React.useRef<Record<string, number> | null>(null);
  const timers = React.useRef<Record<string, number>>({});
  const [changed, setChanged] = React.useState<Record<string, boolean>>({});

  React.useEffect(() => {
    if (!previous.current) {
      previous.current = values;
      return;
    }

    const keys = Object.keys(values).filter((key) => Math.abs(values[key] - (previous.current?.[key] ?? values[key])) > 0.0000001);
    if (keys.length > 0) {
      setChanged((current) => {
        const next = { ...current };
        keys.forEach((key) => { next[key] = true; });
        return next;
      });

      keys.forEach((key) => {
        window.clearTimeout(timers.current[key]);
        timers.current[key] = window.setTimeout(() => {
          setChanged((current) => ({ ...current, [key]: false }));
        }, duration);
      });
    }
    previous.current = values;
  }, [values, duration]);

  React.useEffect(() => () => {
    Object.values(timers.current).forEach((timer) => window.clearTimeout(timer));
  }, []);

  return changed;
}

// Interactive Offset Visualizer Component
function OffsetVisualizer({
  xOff,
  yOff,
  targetLimit,
  onOffsetChange,
  changedValues,
}: {
  xOff: number;
  yOff: number;
  targetLimit: number;
  onOffsetChange: (newX: number, newY: number) => void;
  changedValues: { x: boolean; y: boolean; length: boolean };
}) {
  const SIZE = 240;
  const CENTER = SIZE / 2;
  const SCALE = 22; // pixels per unit

  const toPx = (val: number) => CENTER + val * SCALE;
  const pxX = toPx(xOff);
  const pxY = toPx(-yOff); // flip y for screen
  const displayX = Math.max(8, Math.min(SIZE - 8, pxX));
  const displayY = Math.max(8, Math.min(SIZE - 8, pxY));
  const offsetLength = 2 * Math.sqrt(xOff * xOff + yOff * yOff);
  const calloutX = Math.max(8, Math.min(SIZE - 111, displayX + (displayX > SIZE - 120 ? -106 : 12)));
  const calloutY = Math.max(8, Math.min(SIZE - 58, displayY + (displayY > SIZE - 68 ? -54 : 12)));
  const formatSigned = (value: number) => `${value >= 0 ? '+' : ''}${value.toFixed(4)}`;

  const [dragging, setDragging] = React.useState(false);

  const handlePointer = (clientX: number, clientY: number, elem: HTMLDivElement) => {
    const rect = elem.getBoundingClientRect();
    const rawX = (clientX - rect.left - CENTER) / SCALE;
    const rawY = -(clientY - rect.top - CENTER) / SCALE;
    // The graph moves in exact 0.1-unit increments.
    const nx = Math.round(rawX * 10) / 10;
    const ny = Math.round(rawY * 10) / 10;
    onOffsetChange(nx, ny);
  };

  const onMouseMove = (e: React.MouseEvent) => {
    if (!dragging) return;
    handlePointer(e.clientX, e.clientY, e.currentTarget as HTMLDivElement);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!dragging) return;
    const t = e.touches[0];
    handlePointer(t.clientX, t.clientY, e.currentTarget as HTMLDivElement);
  };

  return (
    <div className="relative select-none">
      <div
        className="relative bg-white border border-slate-300 rounded-3xl overflow-hidden cursor-crosshair shadow-inner"
        style={{ width: SIZE, height: SIZE }}
        onMouseDown={(e) => { setDragging(true); handlePointer(e.clientX, e.clientY, e.currentTarget as HTMLDivElement); }}
        onMouseUp={() => setDragging(false)}
        onMouseLeave={() => setDragging(false)}
        onMouseMove={onMouseMove}
        onTouchStart={(e) => { setDragging(true); const t = e.touches[0]; handlePointer(t.clientX, t.clientY, e.currentTarget as HTMLDivElement); }}
        onTouchEnd={() => setDragging(false)}
        onTouchMove={onTouchMove}
      >
        {/* Grid */}
        <svg width={SIZE} height={SIZE} className="absolute inset-0 pointer-events-none">
          <defs>
            <pattern id="grid" width="22" height="22" patternUnits="userSpaceOnUse">
              <path d="M 22 0 L 0 0 0 22" fill="none" stroke="#e2e8f0" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          
          {/* Target Limit Circle */}
          <circle
            cx={CENTER}
            cy={CENTER}
            r={targetLimit * SCALE}
            fill="none"
            stroke="#22c55e"
            strokeWidth="2"
            strokeDasharray="4 3"
            opacity="0.85"
          />
          {/* Inner 0.5 circle reference */}
          <circle
            cx={CENTER}
            cy={CENTER}
            r={0.5 * SCALE}
            fill="none"
            stroke="#f59e0b"
            strokeWidth="1.5"
            opacity="0.5"
          />

          {/* Axes */}
          <line x1={0} y1={CENTER} x2={SIZE} y2={CENTER} stroke="#cbd5e1" strokeWidth="1.5" />
          <line x1={CENTER} y1={0} x2={CENTER} y2={SIZE} stroke="#cbd5e1" strokeWidth="1.5" />

          {/* Live X/Y projections make the measured components easy to read. */}
          <line x1={displayX} y1={CENTER} x2={displayX} y2={displayY} stroke="#a855f7" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1={CENTER} y1={displayY} x2={displayX} y2={displayY} stroke="#06b6d4" strokeWidth="1.5" strokeDasharray="3 3" />

          {/* Vector */}
          <line
            x1={CENTER}
            y1={CENTER}
            x2={displayX}
            y2={displayY}
            stroke="#3b82f6"
            strokeWidth="3"
            strokeLinecap="round"
          />
          {/* Point */}
          <circle cx={displayX} cy={displayY} r="8" fill="#3b82f6" stroke="#fff" strokeWidth="2.5" />
          <circle cx={displayX} cy={displayY} r="12" fill="none" stroke="#60a5fa" strokeWidth="1.5" opacity="0.65" />
          {/* Center dot */}
          <circle cx={CENTER} cy={CENTER} r="3.5" fill="#64748b" />

          {/* Values stay inside the plot and update continuously while dragging. */}
          <g transform={`translate(${calloutX} ${calloutY})`}>
            <rect width="103" height="50" rx="8" fill="#0f172a" opacity="0.94" stroke="#67e8f9" strokeWidth="1" />
            <text x="8" y="14" fill={changedValues.x ? '#ff5a00' : '#c4b5fd'} fontSize="9" fontWeight={changedValues.x ? '800' : '400'} fontFamily="monospace">X {formatSigned(xOff)}</text>
            <text x="8" y="28" fill={changedValues.y ? '#ff5a00' : '#67e8f9'} fontSize="9" fontWeight={changedValues.y ? '800' : '400'} fontFamily="monospace">Y {formatSigned(yOff)}</text>
            <text x="8" y="42" fill={changedValues.length ? '#ff5a00' : '#fde047'} fontSize="9" fontWeight="800" fontFamily="monospace">L {offsetLength.toFixed(4)}</text>
          </g>
        </svg>

        {/* Labels */}
        <div className="absolute top-2 right-3 text-[10px] bg-white/90 px-2 py-0.5 rounded font-mono shadow text-slate-600 border border-slate-200">
          Drag · step 0.1
        </div>
        <div className="absolute bottom-2 left-3 rounded-md bg-white/90 px-2 py-0.5 text-[10px] font-mono text-slate-600 shadow-sm">
          <span className={changedValues.x ? 'changed-value' : ''}>X {formatSigned(xOff)}</span>
          {' | '}
          <span className={changedValues.y ? 'changed-value' : ''}>Y {formatSigned(yOff)}</span>
          {' | '}
          <span className={changedValues.length ? 'changed-value' : ''}>L {offsetLength.toFixed(4)}</span>
        </div>
      </div>
      
      <div className="flex justify-center gap-3 text-[10px] mt-1.5 text-slate-500">
        <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-px bg-[#22c55e]"></span> Target ≤ {targetLimit}</span>
        <span className="flex items-center gap-1"><span className="inline-block w-2.5 h-px bg-[#f59e0b]"></span> 0.5 ref</span>
      </div>
    </div>
  );
}

function PinBoardVisualizer({
  cavity,
  selectedPin,
  pins,
  onSelect,
}: {
  cavity: Cavity;
  selectedPin: string;
  pins: Array<{ pin: string; pass: boolean; length: number }>;
  onSelect: (pin: string) => void;
}) {
  const coordinates = PIN_NAMES.map((pinName) => ALL_DATA[cavity][pinName]);
  const minX = Math.min(...coordinates.map((point) => point.dX));
  const maxX = Math.max(...coordinates.map((point) => point.dX));
  const minY = Math.min(...coordinates.map((point) => point.dY));
  const maxY = Math.max(...coordinates.map((point) => point.dY));
  const selected = pins.find((item) => item.pin === selectedPin);
  const selectedInfo = ALL_DATA[cavity][selectedPin];

  return (
    <div className="pin-map motion-enter relative min-h-[420px] md:min-h-[520px] overflow-hidden rounded-[26px] border border-cyan-300/40 bg-slate-950 shadow-[0_18px_45px_-22px_rgba(6,182,212,0.8)]">
      <img
        src="/images/pcb-board.jpg"
        alt={`Top-down PCB test point map for cavity ${cavity}`}
        className="absolute inset-0 h-full w-full object-cover opacity-90"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-[#071b2d]/70 via-transparent to-[#1f1147]/55" />
      <div className="scan-line pointer-events-none absolute inset-x-0 h-px bg-cyan-300/80 shadow-[0_0_18px_4px_rgba(34,211,238,0.7)]" />

      <div className="absolute left-5 top-4 z-20 flex items-center gap-3">
        <div className="h-14 w-14 overflow-hidden rounded-xl border border-cyan-300/50 bg-white/95 shadow-lg">
          <img src="/images/abs-module.png" alt="ABS hydraulic control unit" className="h-full w-full object-contain p-0.5" />
        </div>
        <div>
          <div className="text-[11px] font-extrabold tracking-[2px] text-cyan-200">LIVE PCB PIN MAP</div>
          <div className="mt-0.5 text-lg font-bold text-white">Cavity {cavity} inspection image</div>
        </div>
      </div>

      {/* Legend */}
      <div className="absolute right-5 top-4 z-20 flex flex-col gap-1.5 rounded-xl bg-slate-950/70 px-3 py-2 text-[11px] font-semibold text-white backdrop-blur">
        <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-full bg-emerald-400 shadow-[0_0_8px_2px_rgba(52,211,153,0.7)]" /> PASS</span>
        <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-full bg-rose-500 shadow-[0_0_8px_2px_rgba(244,63,94,0.7)]" /> FAIL</span>
        <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-full bg-fuchsia-400 shadow-[0_0_8px_2px_rgba(232,121,249,0.8)]" /> SELECTED</span>
      </div>

      {pins.map((item) => {
        const point = ALL_DATA[cavity][item.pin];
        const left = 7 + ((point.dX - minX) / Math.max(maxX - minX, 1)) * 86;
        const top = 16 + ((maxY - point.dY) / Math.max(maxY - minY, 1)) * 66;
        const active = item.pin === selectedPin;
        return (
          <button
            key={item.pin}
            type="button"
            onClick={() => onSelect(item.pin)}
            aria-label={`Select ${item.pin}, ${item.pass ? 'pass' : 'fail'}`}
            title={`${item.pin} | length ${item.length.toFixed(4)} | ${item.pass ? 'PASS' : 'FAIL'}`}
            className={`group absolute z-10 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white transition-all duration-200 hover:z-30 hover:scale-125 focus:outline-none focus:ring-4 focus:ring-cyan-300/60 ${active ? 'pin-pulse z-30 h-7 w-7 bg-fuchsia-400 shadow-[0_0_26px_10px_rgba(232,121,249,0.8)]' : item.pass ? 'h-4 w-4 bg-emerald-400 shadow-[0_0_12px_3px_rgba(52,211,153,0.65)]' : 'h-4 w-4 bg-rose-500 shadow-[0_0_12px_3px_rgba(244,63,94,0.7)]'}`}
            style={{ left: `${left}%`, top: `${top}%` }}
          >
            <span className={`absolute left-1/2 -translate-x-1/2 whitespace-nowrap rounded-lg px-2 py-1 text-[11px] font-bold text-white shadow-xl transition-opacity ${active ? 'top-[-34px] bg-fuchsia-500 opacity-100' : 'top-[-30px] bg-slate-900/90 opacity-0 group-hover:opacity-100'}`}>
              {item.pin} · {item.length.toFixed(3)}
            </span>
          </button>
        );
      })}

      <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-wrap items-end justify-between gap-3 bg-gradient-to-t from-slate-950 via-slate-950/85 to-transparent px-5 pb-4 pt-12 text-white">
        <div>
          <div className="text-[11px] font-bold tracking-widest text-cyan-300">SELECTED TEST POINT</div>
          <div className="text-2xl font-extrabold">{selectedPin}</div>
        </div>
        <div className="flex gap-6 text-right font-mono text-sm">
          <div><span className="block text-xs text-slate-400">DRAW X</span>{selectedInfo?.dX.toFixed(3)}</div>
          <div><span className="block text-xs text-slate-400">DRAW Y</span>{selectedInfo?.dY.toFixed(3)}</div>
          <div><span className="block text-xs text-slate-400">LENGTH</span><span className={selected?.pass ? 'text-emerald-300' : 'text-rose-300'}>{selected?.length.toFixed(4)}</span></div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [cavity, setCavity] = useState<Cavity>('L1');
  const [pin, setPin] = useState<string>(PIN_NAMES[0]);
  const [readings, setReadings] = useState<Record<string, PinReading>>(createInitialReadings);
  const [targetLength, setTargetLength] = useState<number>(0.5);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<{ key: 'length' | 'pin' | 'xOff' | 'yOff'; dir: 'asc' | 'desc' }>({ key: 'length', dir: 'asc' });
  const [showOnlyFails, setShowOnlyFails] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const currentKey = `${cavity}|${pin}`;
  const currentReading = readings[currentKey] || { ccdX: 0, ccdY: 0, tempX: 0, tempY: 0 };

  const updateReading = (updates: Partial<PinReading>) => {
    setReadings(prev => ({
      ...prev,
      [currentKey]: { ...prev[currentKey], ...updates },
    }));
  };

  const ccdX = currentReading.ccdX;
  const ccdY = currentReading.ccdY;
  const tempX = currentReading.tempX;
  const tempY = currentReading.tempY;

  const info = ALL_DATA[cavity]?.[pin];

  const result = useMemo(() => computeOffsets(pin, ccdX, ccdY, tempX, tempY, cavity), [pin, ccdX, ccdY, tempX, tempY, cavity]);
  const required = useMemo(() => computeRequiredTemp(pin, ccdX, ccdY, targetLength, cavity), [pin, ccdX, ccdY, targetLength, cavity]);

  const offsetLength = result?.length ?? 0;
  const isPass = offsetLength <= targetLength;

  // Summary data + filters
  const allSummary = useMemo(() => {
    return PIN_NAMES.map(p => {
      const pinInfo = ALL_DATA[cavity][p];
      const key = `${cavity}|${p}`;
      const r = readings[key] || { ccdX: 0, ccdY: 0, tempX: 0, tempY: 0 };
      const res = computeOffsets(p, r.ccdX, r.ccdY, r.tempX, r.tempY, cavity);
      if (!res || !pinInfo) return null;
      return {
        pin: p,
        ccdX: r.ccdX,
        ccdY: r.ccdY,
        xOff: res.xOff,
        yOff: res.yOff,
        length: res.length,
        pass: res.length <= targetLength,
        tempX: r.tempX,
        tempY: r.tempY,
      };
    }).filter(Boolean) as any[];
  }, [cavity, readings, targetLength]);

  const filteredSummary = useMemo(() => {
    let data = [...allSummary];
    
    // Search
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      data = data.filter(d => d.pin.toLowerCase().includes(q));
    }
    
    // Only fails
    if (showOnlyFails) {
      data = data.filter(d => !d.pass);
    }
    
    // Sort
    data.sort((a, b) => {
      let valA: any, valB: any;
      if (sortConfig.key === 'pin') {
        valA = a.pin;
        valB = b.pin;
      } else {
        valA = a[sortConfig.key];
        valB = b[sortConfig.key];
      }
      if (valA < valB) return sortConfig.dir === 'asc' ? -1 : 1;
      if (valA > valB) return sortConfig.dir === 'asc' ? 1 : -1;
      return 0;
    });
    return data;
  }, [allSummary, searchTerm, showOnlyFails, sortConfig]);

  // Pass statistics
  const passStats = useMemo(() => {
    const total = allSummary.length;
    const passCount = allSummary.filter(s => s.pass).length;
    return { total, passCount, failCount: total - passCount, rate: total > 0 ? Math.round((passCount / total) * 100) : 0 };
  }, [allSummary]);

  // Handlers
  const handleCavityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newCavity = e.target.value as Cavity;
    setCavity(newCavity);
    setPin(PIN_NAMES[0]);
    setSearchTerm('');
  };

  const handlePinChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setPin(e.target.value);
  };

  const handleCcdXChange = (e: React.ChangeEvent<HTMLInputElement>) => updateReading({ ccdX: parseFloat(e.target.value) || 0 });
  const handleCcdYChange = (e: React.ChangeEvent<HTMLInputElement>) => updateReading({ ccdY: parseFloat(e.target.value) || 0 });
  const handleTempXChange = (e: React.ChangeEvent<HTMLInputElement>) => updateReading({ tempX: parseFloat(e.target.value) || 0 });
  const handleTempYChange = (e: React.ChangeEvent<HTMLInputElement>) => updateReading({ tempY: parseFloat(e.target.value) || 0 });
  const handleTargetChange = (e: React.ChangeEvent<HTMLInputElement>) => setTargetLength(parseFloat(e.target.value) || 0.5);

  // Nudge helpers
  const nudge = (field: keyof PinReading, delta: number) => {
    const current = currentReading[field];
    updateReading({ [field]: +(current + delta).toFixed(6) });
  };

  // Apply current temp to ALL pins in current cavity
  const applyTempToAll = () => {
    const newReadings = { ...readings };
    PIN_NAMES.forEach(p => {
      const k = `${cavity}|${p}`;
      if (newReadings[k]) {
        newReadings[k] = { ...newReadings[k], tempX, tempY };
      }
    });
    setReadings(newReadings);
    showToast(`Applied Temp (${tempX.toFixed(3)}, ${tempY.toFixed(3)}) to all ${cavity} pins`);
  };

  // Reset all temps in current cavity
  const resetAllTemps = () => {
    const newReadings = { ...readings };
    PIN_NAMES.forEach(p => {
      const k = `${cavity}|${p}`;
      if (newReadings[k]) newReadings[k] = { ...newReadings[k], tempX: 0, tempY: 0 };
    });
    setReadings(newReadings);
    showToast(`Reset all temps for ${cavity}`);
  };

  // Reset all CCD values for current cavity
  const resetAllCcd = () => {
    const newReadings = { ...readings };
    PIN_NAMES.forEach(p => {
      const k = `${cavity}|${p}`;
      const orig = ALL_DATA[cavity][p];
      if (newReadings[k]) newReadings[k] = { ...newReadings[k], ccdX: orig.ccdX, ccdY: orig.ccdY };
    });
    setReadings(newReadings);
    showToast(`Restored original CCD for ${cavity}`);
  };

  // Clear current CCD
  const clearCcd = () => updateReading({ ccdX: 0, ccdY: 0 });
  // Reset current temp
  const resetTemp = () => updateReading({ tempX: 0, tempY: 0 });

  // Set CCD directly from visualizer (offset manipulation)
  const handleOffsetDrag = (newXOff: number, newYOff: number) => {
    if (!info) return;
    // Reverse the offset formula:
    // xOff = ccdX + cX + tempX - dX  =>  ccdX = xOff - cX - tempX + dX
    const newCcdX = newXOff - info.cX - tempX + info.dX;
    const newCcdY = newYOff - info.cY - tempY + info.dY;
    updateReading({ ccdX: +newCcdX.toFixed(6), ccdY: +newCcdY.toFixed(6) });
  };

  // Use current offset drag to change CCD
  const xOff = result?.xOff ?? 0;
  const yOff = result?.yOff ?? 0;
  const changedValues = useRecentChanges({
    ccdX,
    ccdY,
    tempX,
    tempY,
    targetLength,
    xOff,
    yOff,
    length: offsetLength,
    drawX: info?.dX ?? 0,
    drawY: info?.dY ?? 0,
    compX: info?.cX ?? 0,
    compY: info?.cY ?? 0,
    reqTempX: required?.tempX ?? 0,
    reqTempY: required?.tempY ?? 0,
    achievedLength: required?.achievedLen ?? 0,
  });

  // Table sorting
  const toggleSort = (key: 'length' | 'pin' | 'xOff' | 'yOff') => {
    setSortConfig(prev => prev.key === key 
      ? { key, dir: prev.dir === 'asc' ? 'desc' : 'asc' } 
      : { key, dir: 'asc' });
  };

  // Quick select pin
  const selectPin = (p: string) => {
    setPin(p);
    setSearchTerm('');
  };

  // CSV download
  const downloadCsv = () => {
    const limit = targetLength;
    let csv = "Cavity,Pin,DrawingX,CompX,CCDX,TempX,DrawingY,CompY,CCDY,TempY,X_Offset,Y_Offset,Offset_Length,Status\n";
    CAVITIES.forEach(cav => {
      PIN_NAMES.forEach(p => {
        const inf = ALL_DATA[cav][p];
        const key = `${cav}|${p}`;
        const r = readings[key] || { ccdX: 0, ccdY: 0, tempX: 0, tempY: 0 };
        const res = computeOffsets(p, r.ccdX, r.ccdY, r.tempX, r.tempY, cav as Cavity);
        if (!res) return;
        const status = res.length <= limit ? 'PASS' : 'FAIL';
        csv += [cav, p, inf.dX.toFixed(6), inf.cX.toFixed(6), r.ccdX.toFixed(6), r.tempX.toFixed(6), inf.dY.toFixed(6), inf.cY.toFixed(6), r.ccdY.toFixed(6), r.tempY.toFixed(6), res.xOff.toFixed(6), res.yOff.toFixed(6), res.length.toFixed(6), status].join(',') + '\n';
      });
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'pcb_tp_verified_data.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Downloaded full CSV');
  };

  // CSV upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const lines = text.split(/\r?\n/).filter(l => l.trim());
      if (lines.length < 2) { alert('CSV appears empty.'); return; }
      const header = lines[0].toLowerCase().split(',').map(h => h.trim());
      const cavIdx = header.indexOf('cavity');
      const pinIdx = header.indexOf('pin');
      const ccdxIdx = header.indexOf('ccdx');
      const ccdyIdx = header.indexOf('ccdy');
      if ([cavIdx, pinIdx, ccdxIdx, ccdyIdx].some(i => i === -1)) {
        alert('CSV needs: Cavity, Pin, CCDX, CCDY');
        return;
      }
      let count = 0;
      const updated = { ...readings };
      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',').map(c => c.trim());
        const cav = cols[cavIdx] as Cavity;
        const p = cols[pinIdx];
        const nx = parseFloat(cols[ccdxIdx]);
        const ny = parseFloat(cols[ccdyIdx]);
        if (!isNaN(nx) && !isNaN(ny) && CAVITIES.includes(cav) && PIN_NAMES.includes(p)) {
          const k = `${cav}|${p}`;
          updated[k] = { ...updated[k], ccdX: nx, ccdY: ny };
          count++;
        }
      }
      setReadings(updated);
      showToast(`Imported ${count} CCD values`);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Quick presets
  const applyPreset = (type: string) => {
    const newReadings = { ...readings };
    if (type === 'zero') {
      PIN_NAMES.forEach(p => {
        const k = `${cavity}|${p}`;
        if (newReadings[k]) newReadings[k] = { ...newReadings[k], tempX: 0, tempY: 0 };
      });
      showToast('Zeroed all temperature compensations');
    } else if (type === 'maxpass') {
      // Try to compute minimal temps to make every pin pass
      PIN_NAMES.forEach(p => {
        const k = `${cavity}|${p}`;
        const inf = ALL_DATA[cavity][p];
        const r = readings[k] || { ccdX: 0, ccdY: 0, tempX: 0, tempY: 0 };
        const baseX = r.ccdX + inf.cX - inf.dX;
        const baseY = r.ccdY + inf.cY - inf.dY;
        const curLen = 2 * Math.sqrt(baseX * baseX + baseY * baseY);
        if (curLen > targetLength) {
          const s = targetLength / curLen;
          const tx = baseX * s - baseX;
          const ty = baseY * s - baseY;
          newReadings[k] = { ...r, tempX: +tx.toFixed(6), tempY: +ty.toFixed(6) };
        } else {
          newReadings[k] = { ...r, tempX: 0, tempY: 0 };
        }
      });
      showToast('Applied minimum temps to pass all pins');
    } else if (type === 'restore') {
      PIN_NAMES.forEach(p => {
        const k = `${cavity}|${p}`;
        const inf = ALL_DATA[cavity][p];
        newReadings[k] = { ccdX: inf.ccdX, ccdY: inf.ccdY, tempX: 0, tempY: 0 };
      });
      showToast('Restored original data for cavity');
    }
    setReadings(newReadings);
  };

  // Toast helper
  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  };

  // Keyboard nudging
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const step = e.shiftKey ? 0.1 : 0.01;
      if (e.key === 'ArrowRight') { nudge('ccdX', step); e.preventDefault(); }
      if (e.key === 'ArrowLeft')  { nudge('ccdX', -step); e.preventDefault(); }
      if (e.key === 'ArrowUp')    { nudge('ccdY', step); e.preventDefault(); }
      if (e.key === 'ArrowDown')  { nudge('ccdY', -step); e.preventDefault(); }
      if (e.key.toLowerCase() === 't') { resetTemp(); }
      if (e.key.toLowerCase() === 'c') { clearCcd(); }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') { e.preventDefault(); downloadCsv(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [currentReading]);

  return (
    <div className="colorful-bg min-h-screen py-7 px-3 md:px-6">
      <div className="max-w-[1520px] mx-auto">
        {/* Card */}
        <div className="glass-shell motion-enter overflow-hidden rounded-[26px] p-7 shadow-[0_28px_80px_-24px_rgba(15,23,42,0.5)] md:p-8">
          <div className="rainbow-line -mx-8 -mt-8 mb-7 h-1.5" />
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3 border-b pb-5 border-slate-200">
            <div className="flex items-center gap-3">
              <div className="logo-orbit flex h-16 w-16 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-[0_10px_25px_-8px_rgba(124,58,237,0.5)]">
                <img src="/images/abs-module.png" alt="ABS hydraulic control unit" className="h-full w-full object-contain p-1" />
              </div>
              <div>
                <div className="bg-gradient-to-r from-violet-700 via-fuchsia-600 to-cyan-600 bg-clip-text text-[2rem] font-extrabold leading-none tracking-tighter text-transparent">PCB TP</div>
              </div>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2 rounded-2xl border border-violet-200 bg-violet-50 px-3 py-1 text-sm">
                <span className="font-medium text-slate-600">Target Limit</span>
                <input
                  type="number"
                  step="0.01"
                  value={targetLength}
                  onChange={handleTargetChange}
                  className={`w-20 rounded-xl border bg-white py-1 text-center font-mono text-sm font-bold focus:border-blue-500 ${changedValues.targetLength ? 'changed-input' : 'border-slate-300'}`}
                />
              </div>
              {/* Global Pass Rate */}
              <div className="flex items-center gap-2 rounded-2xl border border-emerald-200 bg-gradient-to-r from-emerald-50 to-cyan-50 px-4 py-1 text-sm shadow-sm">
                <div className="font-semibold">Pass Rate</div>
                <div className="font-mono text-xl font-bold tabular-nums text-emerald-600">{passStats.rate}%</div>
                <div className="text-xs text-slate-500">({passStats.passCount}/{passStats.total})</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-[360px,1fr] gap-7 mt-6">
            {/* LEFT: CONTROLS */}
            <div className="rounded-3xl border border-violet-200 bg-gradient-to-b from-violet-50/90 via-white to-cyan-50/70 p-5 shadow-[0_16px_35px_-26px_rgba(109,40,217,0.8)]">
              {/* Cavity / Pin selectors */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-extrabold tracking-[0.6px] text-slate-600 block mb-1">CAVITY</label>
                  <select value={cavity} onChange={handleCavityChange} className="w-full bg-white border border-slate-300 rounded-2xl px-4 py-2.5 text-lg font-semibold focus:outline-none focus:border-blue-500">
                    {CAVITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-extrabold tracking-[0.6px] text-slate-600 block mb-1">PIN</label>
                  <select value={pin} onChange={handlePinChange} className="w-full bg-white border border-slate-300 rounded-2xl px-4 py-2.5 text-lg font-semibold focus:outline-none focus:border-blue-500">
                    {PIN_NAMES.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>

              {/* Quick Pin Grid */}
              <div className="mt-3">
                <div className="flex justify-between text-[10px] font-bold text-slate-500 px-1 mb-1">
                  <div>QUICK SELECT</div>
                  <button onClick={() => setShowOnlyFails(!showOnlyFails)} className="text-blue-600 hover:underline">{showOnlyFails ? 'SHOW ALL' : 'SHOW FAILS ONLY'}</button>
                </div>
                <div className="grid grid-cols-6 sm:grid-cols-8 gap-1">
                  {PIN_NAMES.map(p => {
                    const k = `${cavity}|${p}`;
                    const r = readings[k];
                    const res = computeOffsets(p, r.ccdX, r.ccdY, r.tempX, r.tempY, cavity);
                    const passing = (res?.length ?? 999) <= targetLength;
                    const active = p === pin;
                    return (
                      <button
                        key={p}
                        onClick={() => selectPin(p)}
                        className={`px-1.5 py-[5px] text-[11px] font-semibold rounded-xl transition border ${active ? 'bg-blue-600 text-white border-blue-600 shadow' : passing ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100' : 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100'}`}
                      >
                        {p}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="h-px bg-slate-200 my-5" />

              {/* CCD INPUTS + SLIDERS */}
              <div>
                <div className="flex items-center justify-between mb-1 px-0.5">
                  <div className="text-xs font-bold tracking-wider text-slate-600">CCD READINGS</div>
                  <div className="flex gap-1">
                    <button onClick={() => nudge('ccdX', -0.01)} className="px-2 py-0.5 bg-white border text-xs rounded-lg active:bg-slate-100">-0.01</button>
                    <button onClick={() => nudge('ccdX', 0.01)} className="px-2 py-0.5 bg-white border text-xs rounded-lg active:bg-slate-100">+0.01</button>
                  </div>
                </div>

                <div className="space-y-2.5">
                  {/* CCD X */}
                  <div>
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-600 mb-1">
                      <div>📷 CCD X</div><div className={`font-mono tabular-nums ${changedValues.ccdX ? 'changed-value' : ''}`}>{ccdX.toFixed(5)}</div>
                    </div>
                    <div className="flex gap-2">
                      <input type="range" min={-100} max={100} step="0.001" value={ccdX} onChange={e => updateReading({ ccdX: parseFloat(e.target.value) })} className="flex-1 accent-blue-600" />
                      <input type="number" step="any" value={ccdX} onChange={handleCcdXChange} className={`w-28 rounded-xl border bg-white px-3 py-1 font-mono text-sm ${changedValues.ccdX ? 'changed-input' : 'border-slate-300'}`} />
                    </div>
                  </div>

                  {/* CCD Y */}
                  <div>
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-600 mb-1">
                      <div>📷 CCD Y</div><div className={`font-mono tabular-nums ${changedValues.ccdY ? 'changed-value' : ''}`}>{ccdY.toFixed(5)}</div>
                    </div>
                    <div className="flex gap-2">
                      <input type="range" min={-100} max={100} step="0.001" value={ccdY} onChange={e => updateReading({ ccdY: parseFloat(e.target.value) })} className="flex-1 accent-blue-600" />
                      <input type="number" step="any" value={ccdY} onChange={handleCcdYChange} className={`w-28 rounded-xl border bg-white px-3 py-1 font-mono text-sm ${changedValues.ccdY ? 'changed-input' : 'border-slate-300'}`} />
                    </div>
                  </div>
                </div>
              </div>

              {/* TEMP COMPENSATION + SLIDERS */}
              <div className="mt-5">
                <div className="flex items-center justify-between mb-1 px-0.5">
                  <div className="text-xs font-bold tracking-wider text-slate-600">TEMPERATURE COMPENSATION</div>
                  <div className="flex gap-1">
                    <button onClick={() => nudge('tempX', -0.01)} className="px-2 py-0.5 bg-white border text-xs rounded-lg active:bg-slate-100">-0.01</button>
                    <button onClick={() => nudge('tempX', 0.01)} className="px-2 py-0.5 bg-white border text-xs rounded-lg active:bg-slate-100">+0.01</button>
                  </div>
                </div>

                <div className="space-y-2.5">
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                      <div>🌡️ Temp X</div><div className={`font-mono ${changedValues.tempX ? 'changed-value' : ''}`}>{tempX.toFixed(5)}</div>
                    </div>
                    <div className="flex gap-2">
                      <input type="range" min={-2} max={2} step="0.001" value={tempX} onChange={e => updateReading({ tempX: parseFloat(e.target.value) })} className="flex-1 accent-amber-500" />
                      <input type="number" step="any" value={tempX} onChange={handleTempXChange} className={`w-28 rounded-xl border bg-white px-3 py-1 font-mono text-sm ${changedValues.tempX ? 'changed-input' : 'border-slate-300'}`} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs font-semibold text-slate-600 mb-1">
                      <div>🌡️ Temp Y</div><div className={`font-mono ${changedValues.tempY ? 'changed-value' : ''}`}>{tempY.toFixed(5)}</div>
                    </div>
                    <div className="flex gap-2">
                      <input type="range" min={-2} max={2} step="0.001" value={tempY} onChange={e => updateReading({ tempY: parseFloat(e.target.value) })} className="flex-1 accent-amber-500" />
                      <input type="number" step="any" value={tempY} onChange={handleTempYChange} className={`w-28 rounded-xl border bg-white px-3 py-1 font-mono text-sm ${changedValues.tempY ? 'changed-input' : 'border-slate-300'}`} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 grid grid-cols-2 gap-2">
                <button onClick={clearCcd} className="rounded-2xl py-2 bg-white active:bg-slate-100 border text-sm font-semibold">Clear CCD</button>
                <button onClick={resetTemp} className="rounded-2xl py-2 bg-white active:bg-slate-100 border text-sm font-semibold">Reset Temp</button>
                <button onClick={resetAllTemps} className="col-span-2 text-sm font-semibold rounded-2xl py-2 border bg-slate-100 active:bg-slate-200 text-slate-700">RESET ALL TEMPS IN {cavity}</button>
                <button onClick={resetAllCcd} className="col-span-2 text-sm font-semibold rounded-2xl py-2 border bg-slate-100 active:bg-slate-200 text-slate-700">RESTORE ORIGINAL CCD IN {cavity}</button>
                <button onClick={applyTempToAll} className="col-span-2 text-sm font-semibold rounded-2xl py-[9px] bg-amber-500 active:bg-amber-600 text-white">APPLY CURRENT TEMP TO ALL {cavity} PINS</button>
              </div>

              {/* Presets */}
              <div className="mt-3 flex flex-wrap gap-1.5">
                <button onClick={() => applyPreset('zero')} className="flex-1 text-xs py-1.5 bg-slate-900 active:bg-black text-white font-bold rounded-2xl">ZERO TEMPS</button>
                <button onClick={() => applyPreset('maxpass')} className="flex-1 text-xs py-1.5 bg-emerald-700 active:bg-emerald-800 text-white font-bold rounded-2xl">MAKE ALL PASS</button>
                <button onClick={() => applyPreset('restore')} className="flex-1 text-xs py-1.5 bg-white border font-semibold rounded-2xl active:bg-slate-50">RESTORE ORIGINAL</button>
              </div>

              <div className="h-px my-4 bg-slate-200" />

              {/* CSV */}
              <div className="text-[10px] font-extrabold text-slate-600 tracking-widest mb-1.5 px-0.5">DATA IMPORT / EXPORT</div>
              <div className="flex gap-2">
                <label className="flex-1 cursor-pointer bg-white border border-slate-300 text-sm font-semibold rounded-2xl py-2.5 flex items-center justify-center hover:bg-slate-50 active:bg-blue-50">
                  📤 UPLOAD CSV
                  <input type="file" accept=".csv,.txt" onChange={handleFileUpload} className="hidden" />
                </label>
                <button onClick={downloadCsv} className="flex-1 text-sm font-semibold bg-blue-600 hover:bg-blue-700 transition active:bg-blue-800 text-white rounded-2xl">💾 DOWNLOAD CSV</button>
              </div>
              <div className="text-[10px] text-slate-400 mt-1 px-1">Keyboard: ←→↑↓ to nudge • T = reset temp • C = clear ccd • ⌘S = download</div>
            </div>

            {/* RIGHT: RESULTS + VISUALS */}
            <div>
              {/* Status header */}
              <div className="flex flex-wrap items-center justify-between gap-y-2 mb-3">
                <div>
                  <span className="bg-gradient-to-r from-violet-700 to-fuchsia-600 bg-clip-text text-3xl font-bold tracking-tighter text-transparent">{pin}</span>
                  <span className="ml-2 text-xl font-medium text-cyan-600">· {cavity}</span>
                </div>
                <div className={`px-6 py-[7px] rounded-[50px] text-lg font-bold shadow-lg transition-all duration-300 ${isPass ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-emerald-950 shadow-emerald-200' : 'bg-gradient-to-r from-rose-500 to-orange-400 text-white shadow-rose-200'}`}>
                  {isPass ? '✅ PASS' : `❌ FAIL — ${offsetLength.toFixed(4)} > ${targetLength}`}
                </div>
              </div>

              {/* Generated PCB image with interactive test point overlays */}
              <PinBoardVisualizer
                cavity={cavity}
                selectedPin={pin}
                pins={allSummary}
                onSelect={selectPin}
              />

              {/* INTERACTIVE VISUALIZER + RESULTS */}
              <div className="mt-4 flex flex-col gap-5 xl:flex-row">
                {/* Interactive Visualizer */}
                <div className="flex flex-col items-center rounded-3xl border border-cyan-200 bg-gradient-to-br from-cyan-50 via-white to-violet-50 p-5 shadow-[0_14px_30px_-22px_rgba(8,145,178,0.7)]">
                  <div className="mb-2 self-start text-xs font-bold uppercase tracking-widest text-cyan-700">DRAG TO ADJUST OFFSET</div>
                  <OffsetVisualizer 
                    xOff={xOff} 
                    yOff={yOff} 
                    targetLimit={targetLength} 
                    onOffsetChange={handleOffsetDrag} 
                    changedValues={{
                      x: Boolean(changedValues.xOff),
                      y: Boolean(changedValues.yOff),
                      length: Boolean(changedValues.length),
                    }}
                  />
                  <div className="text-[10px] mt-2 text-slate-400">Dragging directly manipulates CCD values</div>
                </div>

                {/* Live Numbers + Formula */}
                <div className="flex-1">
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: 'X OFFSET', value: (result?.xOff ?? 0).toFixed(6), changed: changedValues.xOff },
                      { label: 'Y OFFSET', value: (result?.yOff ?? 0).toFixed(6), changed: changedValues.yOff },
                      { label: 'LENGTH', value: (result?.length ?? 0).toFixed(6), highlight: true, changed: changedValues.length },
                    ].map((it, i) => (
                      <div key={i} className={`rounded-2xl border p-4 shadow-sm ${i === 0 ? 'border-violet-200 bg-violet-50' : i === 1 ? 'border-cyan-200 bg-cyan-50' : 'border-fuchsia-200 bg-gradient-to-br from-fuchsia-50 to-amber-50'}`}>
                        <div className="text-[9px] font-bold tracking-[1px] text-slate-500">{it.label}</div>
                        <div className={`mt-0.5 font-mono text-[22px] font-extrabold tracking-[-1px] ${it.changed ? 'changed-value' : it.highlight ? 'text-[26px] text-blue-700' : ''}`}>
                          {it.value}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Formula */}
                  <div className="mt-2 rounded-2xl bg-gradient-to-r from-slate-950 via-indigo-950 to-violet-950 p-4 font-mono text-sm leading-relaxed text-slate-200 shadow-lg">
                    <div><span className="text-amber-400">X_offset</span> = CCDX + CompX + TempX – DrawingX</div>
                    <div><span className="text-amber-400">Y_offset</span> = CCDY + CompY + TempY – DrawingY</div>
                    <div><span className="text-amber-400">Offset Length</span> = 2 × √(X_offset² + Y_offset²)</div>
                  </div>

                  {/* Readings */}
                  <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-2 rounded-2xl border border-violet-200 bg-gradient-to-r from-white via-violet-50/50 to-cyan-50/70 px-4 py-3 text-xs sm:grid-cols-4">
                    {[
                      ['CCD X', ccdX, changedValues.ccdX], ['CCD Y', ccdY, changedValues.ccdY],
                      ['Draw X', info?.dX, changedValues.drawX], ['Draw Y', info?.dY, changedValues.drawY],
                      ['Comp X', info?.cX, changedValues.compX], ['Comp Y', info?.cY, changedValues.compY],
                      ['Temp X', tempX, changedValues.tempX], ['Temp Y', tempY, changedValues.tempY],
                    ].map(([lab, val, changed], idx) => (
                      <div key={idx} className="flex justify-between border-b border-slate-100 py-[1px] last:border-b-0">
                        <span className="text-slate-500">{lab}</span>
                        <span className={`font-mono font-semibold ${changed ? 'changed-value' : ''}`}>{(val as number).toFixed(4)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Target Computation Panel */}
              <div className="mt-3 rounded-3xl border border-amber-200 bg-gradient-to-r from-amber-50 via-rose-50 to-fuchsia-50 p-5 shadow-[0_12px_30px_-25px_rgba(245,158,11,0.7)]">
                <div className="font-semibold mb-2 flex items-center gap-2 text-sm">🎯 ACHIEVE TARGET LENGTH — <span className="font-mono text-xs px-2 py-px bg-white border rounded">{targetLength}</span></div>
                <div className="flex flex-wrap gap-x-7 gap-y-1 text-sm">
                  <div>Required <strong>TempX:</strong> <span className={`font-mono font-semibold ${changedValues.reqTempX ? 'changed-value' : ''}`}>{required ? required.tempX.toFixed(6) : '—'}</span></div>
                  <div>Required <strong>TempY:</strong> <span className={`font-mono font-semibold ${changedValues.reqTempY ? 'changed-value' : ''}`}>{required ? required.tempY.toFixed(6) : '—'}</span></div>
                  <div>Achieved Length: <span className={`font-mono font-semibold ${changedValues.achievedLength ? 'changed-value' : ''}`}>{required ? required.achievedLen.toFixed(6) : '—'}</span></div>
                </div>
                <div className="mt-2 text-xs text-slate-500">Apply these temps to get exactly the target length.</div>
              </div>

              {/* SUMMARY TABLE + FILTERS */}
              <div className="mt-4">
                <div className="flex items-center justify-between mb-1.5 px-1">
                  <div className="uppercase font-extrabold text-xs tracking-widest text-slate-500">All Pins — {cavity} ({filteredSummary.length})</div>
                  <div className="flex items-center gap-1">
                    <input
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      placeholder="Search pins..."
                      className="px-3 py-1 text-sm bg-white border rounded-2xl w-40 focus:border-blue-500 outline-none"
                    />
                    <button onClick={() => { setSearchTerm(''); setShowOnlyFails(false); }} className="px-3 py-1 text-xs rounded-2xl border bg-white active:bg-slate-100">Clear</button>
                  </div>
                </div>

                <div className="overflow-hidden rounded-3xl border border-violet-200 bg-white shadow-[0_14px_30px_-26px_rgba(109,40,217,0.8)]">
                  <div className="max-h-[268px] overflow-auto">
                    <table className="w-full text-xs">
                      <thead className="sticky top-0 z-10 bg-gradient-to-r from-violet-100 via-fuchsia-50 to-cyan-100">
                        <tr className="text-violet-800">
                          {['pin', 'xOff', 'yOff', 'length'].map((k, i) => (
                            <th 
                              key={i} 
                              onClick={() => toggleSort(k as any)} 
                              className="text-left pl-4 py-2 cursor-pointer hover:text-blue-600 font-semibold select-none"
                            >
                              {k === 'pin' ? 'PIN' : k === 'xOff' ? 'X OFF' : k === 'yOff' ? 'Y OFF' : 'LENGTH'}
                              {sortConfig.key === k && <span className="ml-1 text-[9px]">{sortConfig.dir === 'asc' ? '↑' : '↓'}</span>}
                            </th>
                          ))}
                          <th className="pl-3 pr-4 text-left font-semibold">STATUS</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredSummary.map((row, idx) => (
                          <tr 
                            key={idx} 
                            onClick={() => selectPin(row.pin)} 
                            className={`cursor-pointer hover:bg-blue-50/60 transition ${row.pin === pin ? 'bg-blue-100/60' : ''}`}
                          >
                            <td className="pl-4 py-[6px] font-bold text-slate-900">{row.pin}</td>
                            <td className="font-mono text-right pr-3">{row.xOff.toFixed(4)}</td>
                            <td className="font-mono text-right pr-3">{row.yOff.toFixed(4)}</td>
                            <td className="font-mono font-bold text-right pr-3 text-slate-900">{row.length.toFixed(4)}</td>
                            <td className="pl-3 pr-4">
                              <span className={`inline-flex items-center gap-1.5 px-2.5 py-[1px] text-[10px] font-bold rounded ${row.pass ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${row.pass ? 'bg-emerald-500' : 'bg-red-500'}`} /> {row.pass ? 'PASS' : 'FAIL'}
                              </span>
                            </td>
                          </tr>
                        ))}
                        {filteredSummary.length === 0 && (
                          <tr><td colSpan={5} className="pl-4 py-4 text-slate-400">No pins match your filter.</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="text-xs text-slate-400 mt-1 pl-1">Click a row or use the pin buttons above to switch. Drag the visualization to change offsets live.</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 text-center text-xs font-medium text-violet-700/70">
          Fully interactive • Drag the plot • Use sliders and arrow keys • Live updates
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 px-6 py-2.5 bg-slate-900 text-white rounded-3xl shadow-2xl text-sm font-medium z-50">
          {toast}
        </div>
      )}
    </div>
  );
}
